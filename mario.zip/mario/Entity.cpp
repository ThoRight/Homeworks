#include "Entity.h"

void Entity::destroy()
{
	m_active = false;
}

