/**
 * @author MuratErbilici
 * @since 03.06.2023
 */

import java.util.*;
import java.io.*;

public class TestCases implements Runnable {

    private  String FileName;
    private int X_SIZE;
    private int Y_SIZE;

    public TestCases(String FileName, int X_SIZE, int Y_SIZE) {
        this.FileName = FileName;
        this.X_SIZE = X_SIZE;
    	this.Y_SIZE = Y_SIZE;
    }



  
    
    public void test()throws IOException{
    	
    	System.out.println("\n\n*******************\nMap is " + this.FileName + " with X_SIZE " + this.X_SIZE + " and Y_SIZE " + this.Y_SIZE + "\n********************\n");
	    //Put your main class here so I can run your code for each map using my Main.java that I shared with you.
        // Your main class will be here
        CSE222Map Map = new CSE222Map (FileName,Y_SIZE,X_SIZE);
        CSE222Graph Graph = new CSE222Graph (Map);
        boolean isValidMap = Map.check();
        Map.convertPNG();
        if(isValidMap){
            List<Vertex> DijkstraPath = Graph.findDijkstraPath();
            List<Vertex> BFSPath = Graph.findBFSPath();
            if(DijkstraPath!=null){
                Map.drawLine(DijkstraPath,0);
                Map.writePath(DijkstraPath,0);
                System.out.println("Dijkstra Path: "+ DijkstraPath.size());
            }
            if(BFSPath!=null){
                Map.drawLine(BFSPath,1);
                Map.writePath(BFSPath,1);
                System.out.println("BFS Path: "+ BFSPath.size());
            }
        }
        else{
            System.out.println("The path cannot be found because starting or end point is not valid.");
        }
    }

    @Override
    public void run(){
        try{
            test();
        }
        catch(IOException e){
            
        }
    }
}

