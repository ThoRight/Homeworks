import javax.swing.JFrame;

class frametesti{
    public static void main(String[] args){
        
    }

}