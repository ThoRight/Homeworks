import java.util.Scanner; // for getting input from user
import java.lang.Thread; // for random function

/**
* @author Murat Erbilici
* @since 20.01.2023
*/
public class Tetris{
    private char[][] board; /* Double pointer of my board */
    private int height; /* Board's height and width */
    private int width;
    private int lc; /* This keeps left bottom corner index of Tetromino that has been just added */
    private int rc; /* This keeps right bottom corner index of Tetromino that has been just added */

/**
* Constructor that creates board according to parameters.
*/
    public Tetris(int height1, int width1){
        int i,j;
        board = new char[height1][width1];

        for(i=0;i<height1;++i)
            for(j=0;j<width1;++j)
                board[i][j] = 0;
        height = height1;
        width = width1;
    }
    public int getHeight(){
        return height;
    }
    public int getWidth(){
        return width;
    }
    public int getlc(){
        return lc;
    }
    public int getrc(){
        return rc;
    }
    public void setlc(int value){
        lc = value;
    }
    public void setrc(int value){
        rc = value;
    }

/**
* Determines wheter it is 'I' tetromino and its position is vertical or not.
* @return true if it's I, false otherwise.
*/    
    private boolean isI(Tetromino piece, char direction){
        if(direction == 'R'){
            if(piece.getshape() == shapes.I && piece.getY()==3 && piece.gettetro(0,0)!=0) return true;
            else return false;
        }
        else if(direction == 'L'){
            if(piece.getshape() == shapes.I && piece.getY()==3 && piece.gettetro(0,0)==0) return true;
            else return false;
        }
        else return false;
    }
/** 
* Determines if its in board or not.
* @return true if its boards boundry, false otherwise.
*/
    private boolean check_index(char direction, int count){
        if(direction == 'R'){
            if(rc+count >= width) return false;
        }
        else if(direction == 'L'){
            if(lc-count<0) return false;
        }
        return true;
    }

/**
* Adds the tetromino default position(at the top row in the middle.)
*/
    public void add(Tetromino piece){
        int i,j,x,y;
        shapes shape;
        shape = piece.getshape();
        x = piece.getX();
        y = piece.getY();

        lc=width/2-1;
        rc=lc+x-1;

        for(i=0;i<y;i++){
            if(x==3){
                board[i+3][width/2-1] = piece.gettetro(i,0);  /* Since some pieces have 2 columns and some pieces have 3 columns*/
                board[i+3][width/2] = piece.gettetro(i,1);    /* wrote these two if statements */
                board[i+3][width/2+1] = piece.gettetro(i,2);
            }
            else if(x==2){
                board[i+3][width/2-1] = piece.gettetro(i,0);
                board[i+3][width/2] = piece.gettetro(i,1); 
            }
        }
    }
/**
* Adds piece to new position in the board after rotating
*/
    public void add(Tetromino piece, int y, int x){
        int i,j,tempx;
        for(i=0;i<piece.getY();++i){
            tempx=x;
            for(j=0;j<piece.getX();++j){
                board[i][tempx] = piece.gettetro(i,j);
                ++tempx;
            }
        }
    }

/**
* Draws the board
*/
    public void draw(){
        int i,j,row,column;

        row = getHeight();
        column = getWidth();

        for(i=0;i<column+2;++i) System.out.printf("#");
        System.out.printf("\n");
        for(i=3;i<row;++i){
            System.out.printf("|");
            for(j=0;j<column;++j){
                if(board[i][j]==0) System.out.printf(" ");
                else System.out.printf("%c", board[i][j]);
            }
            System.out.printf("|");
            System.out.printf("\n");
        }
        for(i=0;i<column+2;++i) System.out.printf("-");;
        System.out.printf("\n");
    }

/**
* Animates the added tetromino droping to the bottom of the board.
*/
    public void animate(Tetromino piece){
        int i,j,k,start_column,end_row,pieceRow,count=0;
        int flag=1;
        int z=0;
        boolean check=true;
        char[][] tempboard;
        String direction;
        Scanner input1 = new Scanner(System.in);
        Scanner input2 = new Scanner(System.in);
        Scanner input3 = new Scanner(System.in);
        Scanner input4 = new Scanner(System.in);

        while(true){
            System.out.printf("Choose the direction to rotate piece(R for right, L for left, 0 for no rotation): ");
            direction = input1.nextLine();
            int delay;
            if(direction.length()!=1 || (direction.charAt(0) != 'R' && direction.charAt(0) != 'L' && direction.charAt(0) != '0'))
                System.out.println("Please enter proper input!");
            else break;
        }
        if(direction.charAt(0)!='0'){
            do{
                System.out.printf("Enter the rotation count: ");
                while (!input2.hasNextInt()) {
                    System.out.println("Please enter proper input!");
                    input2.next();
                }
                count = input2.nextInt();
                if(count < 0)
                    System.out.println("Please enter proper input!");
            }while(count < 0);
        }
        erase(piece);
    
        if(direction.charAt(0)!='0' && piece.getshape()!= shapes.O)
            for(i=0;i<count;++i) piece.rotate(direction.charAt(0));
    
    
        this.add(piece);
        System.out.print("\033[H\033[2J");  
        this.draw();

        // This is for preventing the any problem caused by empty part of 'I' tetromino (because it has 2d)
        if(piece.getshape()==shapes.I && piece.getX()==3 && piece.gettetro(0,0)!=0)
            piece.verticalreverse();
   
        while(true){
            System.out.printf("Choose the direction to move piece(R for right, L for left, 0 for no movement): ");
            direction = input3.nextLine();
            if(direction.length()!=1 || (direction.charAt(0) != 'R' && direction.charAt(0) != 'L' && direction.charAt(0) != '0'))
                System.out.printf("Please enter proper input!\n");
            else break;
        }
        if(direction.charAt(0)!='0'){
            do{
                System.out.printf("Enter the movement count: ");
                while (!input4.hasNextInt()) {
                    System.out.println("Please enter proper input!");
                    input4.next();
                }
                count = input4.nextInt();
                if(count < 0)
                    System.out.println("Please enter proper input!");
            }while(count < 0);
        }
    
        boolean check2 = isI(piece, direction.charAt(0));
    
    
        //Special movement for vertical 'I' Tetromino
        if(check2==true && board[3][lc]==0 && lc-count>=-1){
            piece.rotate('R');
            piece.rotate('R');
            lc-=count-1;
            rc-=count-1;
        }
        else if(check2==true && board[3][lc]!=0 && lc+count<width){
            piece.rotate('R');
            piece.rotate('R');
            lc+=count-1;
            rc+=count-1;
        }
        else if(check2==true) check=false;
    
    
        else check = check_index(direction.charAt(0), count);
        if(check==false){
            erase(piece);
            System.out.print("\033[H\033[2J");   
            this.draw();
            System.out.printf("Wrong input. Please stay the board's boundry!\n");
        }
        else{
            if(check2!= true && direction.charAt(0) == 'R'){
                lc+=count;
                rc+=count;
            }
            else if(check2!= true && direction.charAt(0) == 'L'){
                lc-=count;
                rc-=count;
            }
            erase(piece);
            pieceRow = piece.getY();
            start_column=lc;
            end_row=3;
            for(i=4;i<height;++i){ /* Start looking from top until touch the ground or another tetromino */
                end_row=i-1;
                for(j=lc;j<lc+piece.getX();++j){
                    if(board[i][j] !=0 && piece.gettetro(pieceRow-1,z) !=0){
                        flag=0;
                        break;
                    }
                    else if((board[i][j] !=0 && piece.gettetro(pieceRow-1,z) == 0 && piece.gettetro(pieceRow-2,z)!=0)){
                        if(z==0 && i!=height-1 && piece.gettetro(pieceRow-1,z+1)!=0 && board[i][j+1]!=0){
                            flag=0;
                            break;
                        }
                        flag=0;
                        end_row = i;
                        break;
                    }
                    ++z;
                }
                if(flag==0) break;
                z=0;
            }
            if(flag==1) end_row=height-1;
            if(end_row-piece.getY()==2){
                System.out.printf("GAME OVER!\n");
                System.exit(0);
            }

            add(piece,end_row,start_column);


            tempboard = new char[height][width];

            for(i=0;i<height;++i)
                for(j=0;j<width;++j)
                    tempboard[i][j] = board[i][j];

            this.draw();

            for(k=end_row-piece.getY()+1;k>0;--k){    /* Each step, piece's row decrement by one */
                for(i=end_row;i>0;--i){
                    for(j=start_column;j<piece.getX()+start_column;++j){
                        board[i][j] = board[i-1][j];
                        board[i-1][j] = 0;
                    }
                }
                System.out.print("\033[H\033[2J");  
                this.draw();
                try{
                    Thread.sleep(50);
                } 
                catch(InterruptedException e){
                // this part is necessary for sleep function
                }
            }       
            for(i=0;i<this.height;++i){  /* After decrementing, Equalizing board and tempboard with some conditions to prevent losing any part of pieces */
                for(j=0;j<this.width;++j){
                    if((board[i][j] != tempboard[i][j] && tempboard[i][j] != 0 && board[i][j] != 0 )|| (tempboard[i][j]!=0 && board[i][j]==0 && i>3)) 
                        board[i][j] =tempboard[i][j];
                }
            }
            System.out.print("\033[H\033[2J");  
            if(end_row-piece.getY()+1 > 5){
                this.erase(piece);
                this.erase(piece,start_column);
            }
            this.draw();
        }
    }

/**
* Erases the default position of piece after new location of piece is determined.
*/
    public void erase(Tetromino piece){
        int i,x,y;
    
        shapes shape;
        shape = piece.getshape();
    
        x = piece.getX();
        y = piece.getY();
    
        for(i=0;i<y;i++){
            if(x==3){
                board[i+3][width/2-1] = 0;
                board[i+3][width/2] = 0;
                board[i+3][width/2+1] = 0;
            }
            else if(x==2){
                board[i+3][width/2-1] = 0;
                board[i+3][width/2] = 0;
            }
        }
    }

/**
* Erase the piece by starting from start column
*/
    public void erase(Tetromino piece, int start_column){
        int i,j;
        for(i=0;i<piece.getY();++i)
            for(j=start_column;j<piece.getX()+start_column;++j)
                board[i][j]=0;
    }

/**
* After initializing board, starts the game for user.
*/
    public void play(){
        Scanner inp = new Scanner(System.in);
        int random;
        shapes shape = shapes.O;
        System.out.print("\033[H\033[2J");  
        this.draw();
        while(true){
            System.out.printf("Enter tetromino type (Capital I,O,T,J,L,S,Z) (R for random, Q for quit.)\n");
            char type;
            while(true){
                String input;
                while(true){
                input = inp.nextLine();
                type = input.charAt(0);
                if(input.length()>1 ||(type!='I' && type!='O' && type!='T' && type!='J' && 
                type!='L' && type!='S' && type!='Z' && type!= 'R' && type!='Q'))
                    System.out.printf("Please enter the proper input.\n");
                else break;
                }
                if(type=='Q') break;
			    else if(type == 'R'){
                    random = (int)(Math.random() * 7);
                    switch(random){       
                        case 0: 
                            type = 'I';
                            shape = shapes.I;
                        break;
                        case 1: 
                            type = 'S';
                            shape = shapes.S;
                        break;
                        case 2:
                            type = 'Z';
                            shape = shapes.Z;
                        break;
                        case 3: 
                            type = 'L';
                            shape = shapes.L;
                        break;
                        case 4:
                            type = 'T';
                            shape = shapes.T;
                        break;
                        case 5: 
                            type = 'J';
                            shape = shapes.J;
                        break;
                        case 6: 
                            type = 'O';
                            shape = shapes.O;
                        break;
                    }
                }
                else{
                    switch(type){
                        case 'I': shape = shapes.I;
                        break;
                        case 'S': shape = shapes.S;
                        break;
                        case 'Z': shape = shapes.Z;
                        break;
                        case 'L': shape = shapes.L;
                        break;
                        case 'T': shape = shapes.T;
                        break;
                        case 'J': shape = shapes.J;
                        break;
                        case 'O': shape = shapes.O;
                        break;
                    }
                }
                break;
		    }
            if(type =='Q'){
                System.out.printf("Quitting....\n");
                break;
            }
            Tetromino t = new Tetromino(shape); 
            this.add(t);
            System.out.print("\033[H\033[2J");  

            this.draw();
            try{
                Thread.sleep(50);
            } 
            catch(InterruptedException e){
             // this part is necessary for sleep function.
            }
            this.animate(t);       
        } 
    }











}