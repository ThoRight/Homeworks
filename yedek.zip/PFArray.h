#ifndef PFARRAY_H_
#define PFARRAY_H_

#include <memory>
#include <iterator>
#include <iostream>

using namespace std;


namespace MuratArray
{
    template<typename T>
    class PFArray
    {
    public:
        class Iterator{
        public:

            using iterator_category = random_access_iterator_tag;
            using value_type = T;
            using difference_type = ptrdiff_t;
            using pointer = T*;
            using reference = T&;


            Iterator(T* newptr);
            Iterator& operator++();
            Iterator operator++(int);
            Iterator& operator--();
            Iterator& operator--(int);
            T& operator*();
            T* operator->()const;
            bool operator==(const Iterator& iter);
            bool operator!=(const Iterator& iter);
            bool operator<(const Iterator& iter);
            bool operator<=(const Iterator& iter);
            bool operator>(const Iterator& iter);
            bool operator>=(const Iterator& iter);
            Iterator& operator=(const Iterator& oth);
            Iterator operator+(ptrdiff_t  k);
            int& operator[](ptrdiff_t  k);
            Iterator operator-(ptrdiff_t  k);
            ptrdiff_t operator-(const Iterator& oth)const;
            T* getptr()const;

        private:
            T* ptr;
        };

        PFArray(); //Initializes with a capacity of 50.
        PFArray(int capacityValue);
        PFArray(const PFArray<T>& pfaObject);
        void addElement(const T& element);
        bool full( ) const; // Checks if array is full.
        int getCapacity( ) const;
        int getNumberUsed( ) const;
        void emptyArray( );

        bool empty()const;
        //Resets the number used to zero, effectively emptying the array.

        T& operator[](int index);
        PFArray<T>& operator=(const PFArray<T>& rightSide);

        PFArray<T>& operator=(const PFArray&& source); //move sementics
        PFArray( PFArray<T>&& source);

        Iterator begin();
        Iterator end();
        const Iterator cbegin();
        const Iterator cend();
        int size();
        void erase(Iterator position);
        void clear();

    private:
        shared_ptr<T[]> a; //for an array of T.
        int capacity; //for the capacity of the array.
        int used; //for the number of array positions currently in use.
    };

}// MuratArray

#endif /* PFARRAY_H_ */

