#include "PFArray.cpp"

using namespace MuratArray;

int main(){
    PFArray<int> pfarr(10);
    pfarr[11] = 1;
}