#include <iostream>
#include <vector>
#include <algorithm>
#include <memory>

using namespace std;

class A{
    public:
    A(){
        a=10;
    }
    int operator++(){
        int b = a + 1;
        return b;
    }
    int a;
};

int main(){
    A b;
    cout << b.a << endl;
    cout << b.operator++() << endl;

    int deneme[10];
    cout << &deneme[2] - &deneme[0];

        vector<int> vec { 10, 20, 30, 40 };
  
    // Iterator used to store the position
    // of searched element
    vector<int>::iterator it;
    cout << "\n\n\n";
    // Print Original Vector
   cout << "Original vector :";
    for (int i=0; i<vec.size(); i++)
        cout << " " << vec[i];
  
   cout << "\n";
  
    // Element to be searched
    int ser = 10;
  
    // std::find function call
    it = find (vec.begin(), vec.end(), ser);
    if (it != vec.end())
    {
        cout << "Element " << ser <<" found at position : " ;
        cout << it - vec.begin() << " (counting from zero) \n" ;
    }
    else
        cout << "Element not found.\n\n";
  
    shared_ptr<int[]> d1 = shared_ptr<int[]>(new int[10]);
    shared_ptr<int[]> d2 = shared_ptr<int[]>(new int[5]);
    d2[3] = 5;
    cout << d1[3] << "  ";
    d2 = d1;
    d2[10] = 3;
    d2 = nullptr;
    cout << d1[3] << "  ";
    d1[3] = 2;
    cout << d1[3] << "  ";

    return 0;
}