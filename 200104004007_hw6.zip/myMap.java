/**
 * @author MuratErbilici
 * @since 10.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class myMap{
    private LinkedHashMap <String, info> map;
    private int mapSize;
    private String str;

    /**
     * Constructor with input which is not preprocessed yet.
     */
    public myMap(String input){
        mapSize = 0;
        map = new LinkedHashMap<String,info>();
        str = preprocessing(input);
        createMap();
    }
    /**
     * no parameter Constructor. it is for mergesort algorithm.
     */
    public myMap(){
        mapSize = 0;
        map = new LinkedHashMap<String,info>();
    }
    /**
     * to print str.
     */
    public void printString(){
        System.out.printf("%s\n", str);
    }
    /**
     * it takes str as an input and turns it to desired string.
     */
    public String preprocessing(String str){
        String temp = "";
        for(int i=0;i<str.length();++i){
            if(str.charAt(i) >='a' && str.charAt(i) <= 'z'){
                temp+=str.charAt(i);
            }
            else if(str.charAt(i) >= 'A' && str.charAt(i) <= 'Z'){
                char c = str.charAt(i);
                c+=32;
                temp+=c;
            }
            else if(str.charAt(i) == ' '){
                temp+=str.charAt(i);
            }
        }
        return temp;
    }
    public boolean checkInput(String input){
        for(int i=0;i<input.length();++i){
            if(input.charAt(i)!=' ')
                return true;
        }
        return false;
    }

    /**
     * According to str, builds the map. While building map, it designes info objects according to char and char numbers .
     * 
     */
    private void createMap(){
        // it allows us to detect the word according to character of string and add it to info object.
        ArrayList<String> seperatedWords = divideIntoWords();
        int index=0;
        int alistindex=0;
        boolean isSpace = false;
        for(int i=0;i<str.length();++i){
            if(str.charAt(i)!=' ')
                break;
            ++index;
        }
        for(int i=index;i<str.length();++i){
            String tempStr="";
            tempStr+=str.charAt(i);
            if(str.charAt(i) == ' ') isSpace = true;
            else if(isSpace){
                ++alistindex;
                isSpace=false;
            }
            if(map.containsKey(tempStr)){
                info info = map.get(tempStr);
                info.push(seperatedWords.get(alistindex));
            }
            else if(str.charAt(i) != ' '){
                info info = new info(seperatedWords.get(alistindex));
                String temp ="";
                temp+=str.charAt(i);
                map.put(temp,info);
                ++mapSize;
            }
        }
    }
    /**
     * to print the map.
     */
    public void printMap(){
        Set<String> keys = map.keySet();
        for(String key : keys){
            System.out.printf("Letter: %s - ", key);
            info info = map.get(key);
            info.printInfo();
        }
    }
    /**
     * it divides the string into words to determine which word contains the character. 
     */
    private ArrayList<String> divideIntoWords(){
        ArrayList<String> tempList = new ArrayList<String>();
        String tempStr = "";
        for(int i=0;i<str.length();++i){
            if(str.charAt(i) != ' '){
                tempStr += str.charAt(i);
            }
            if(str.charAt(i) == ' ' && tempStr.length()!=0 || i==str.length()-1 && tempStr.length()!=0){
                tempList.add(tempStr);
                tempStr = "";
            }
        }
        return tempList;
    }

    /**
     * getter for mapSize.
     */
    public int getMapSize(){
        return mapSize;
    }

    /**
     * getter for str.
     */
    public String getStr(){
        return str;
    }
    /**
     * getter for map.
     */
    public LinkedHashMap<String,info> getLinkedHashMap(){
        return map;
    }

    /**
     * it is same as LinkedHashMap.put but it works with myMap class.
     */
    public void put(String str, info info){
        map.put(str,info);
        ++mapSize;
    }
    /**
     * it is same as LinkedHashMap.get but it works with myMap class.
     */
    public info get(String key){
        return map.get(key);
    }
    /**
     * setter for str.
     */
    public void setStr(String str){
        this.str = str;
    }


}
