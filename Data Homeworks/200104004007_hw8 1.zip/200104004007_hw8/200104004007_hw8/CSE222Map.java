/**
 * @author MuratErbilici
 * @since 03.06.2023
 */

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

public class CSE222Map{
    private int starting_point_y;
    private int starting_point_x;
    private int end_point_y;
    private int end_point_x;
    private int [][] matrix;
    private int rowNum;
    private int columnNum;
    private String filename;
    private String onlyMapName;

    /**
     * Constructor to create map
     * @param filename filename to read.
     * @param y row number of map.
     * @param x column number of map.
     */
    public CSE222Map(String filename, int y, int x) throws IOException{
        this.filename = filename;
        this.rowNum = y;
        this.columnNum = x;
        this.onlyMapName="";
        matrix = new int[rowNum][columnNum];
        getOnlyMapName();
        read_from_file();
    }
    /**
     * to obtain txt name without(.txt) to create png files with same name.
     */
    private void getOnlyMapName(){
        Scanner sc = new Scanner(filename);
        sc.useDelimiter(".txt");
        onlyMapName = sc.next();
    }
    /**
     * read file to create map.
     */
    private void read_from_file() throws IOException{
        File file = new File(filename);
        Scanner sc = new Scanner(file);
        Scanner sc2;
        String temp;
        int y=0;
        int x=0;
        for(int i=0;i<2;++i){
            temp = sc.nextLine();
            sc2 = new Scanner(temp);
            sc2.useDelimiter(",");
            if(i==0){
                starting_point_y = Integer.parseInt(sc2.next());
                starting_point_x = Integer.parseInt(sc2.next());
            }
            else{
                end_point_y = Integer.parseInt(sc2.next());
                end_point_x = Integer.parseInt(sc2.next());
            }
        }
        while(y<rowNum && sc.hasNextLine()){
            temp = sc.nextLine();
            sc2 = new Scanner(temp);
            sc2.useDelimiter(",");
            x=0;
            while(x<columnNum && sc2.hasNext()){
                int value = Integer.parseInt(sc2.next());
                if(value != 0) value = 1;
                matrix[y][x] = value;
                ++x;
            }
            ++y;
        }
    }
    /**
     * According to matrix, it creates png file.
     */
    public void convertPNG() throws IOException{
        try{
            BufferedImage image = new BufferedImage(columnNum, rowNum, BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < rowNum; ++y){
                for (int x = 0; x < columnNum; ++x){
                    if (matrix[y][x] == 0){
                        image.setRGB(x, y, Color.WHITE.getRGB());
                    }
                    else if(matrix[y][x] == 1){
                        image.setRGB(x, y, Color.LIGHT_GRAY.getRGB());
                    }
                }
            }
        
            Path outputPath = Paths.get(onlyMapName+"Img.png");
            ImageIO.write(image, "PNG", outputPath.toFile());
            System.out.printf("%s converted to %sImg.png file.\n", filename, onlyMapName);
        }
        catch(IOException e){

        }
    }
    /**
     * According to path found, it draw the path to png file.
     * @param shortestPath Vertex list of Shortest path.
     * @param type it indicates which algorithm used. 0 for dijkstra, 1 for BFS.
     */
    public void drawLine(List<Vertex> shortestPath, int type) throws IOException{
        try{
            File file = new File(onlyMapName+"Img.png");
            BufferedImage image = ImageIO.read(file);
            for(int i=0;i<shortestPath.size();++i){
                if(type==0 && shortestPath.get(i) != null)
                    image.setRGB(shortestPath.get(i).getX(),shortestPath.get(i).getY(), Color.RED.getRGB());
                else if(type==1 && shortestPath.get(i) != null)
                    image.setRGB(shortestPath.get(i).getX(),shortestPath.get(i).getY(), Color.BLUE.getRGB());
            }
            Path outputPath = Paths.get(onlyMapName+"Img.png");
            ImageIO.write(image, "PNG", outputPath.toFile());
            if(type==0)    
                System.out.printf("%s DijkstraPath has been drawn to %s.png file.(RED)\n", onlyMapName, onlyMapName);
            else if(type==1)
                System.out.printf("%s BFSPath has been drawn to %s.png file.(BLUE)\n", onlyMapName, onlyMapName);
        }
        catch(IOException e){

        }
    }
    /**
     * to write coordinates of path to another txt file.
     * @param shortestPath vertex list of shortest path.
     * @param type it indicates which algorithm used. 0 for dijkstra, 1 for BFS.
     */
    public void writePath(List<Vertex> shortestPath, int type)  throws IOException{
        FileWriter file;
        if(type==0)
            file = new FileWriter(onlyMapName+"DijkstraPath.txt");
        else
            file = new FileWriter(onlyMapName+"BFSPath.txt");
        for(int i=0;i<shortestPath.size();++i){
            if(shortestPath.get(i) != null)
                file.write(shortestPath.get(i).getY()+","+shortestPath.get(i).getX()+"\n");
        }
        file.close();
        if(type==0)
            System.out.printf("%s DijkstraPath has been written to %sDijkstraPath.txt file.\n",onlyMapName, onlyMapName);
        if(type==1)
            System.out.printf("%s BFSPath has been written to %sBFSPath.txt file.\n",onlyMapName, onlyMapName);
    }
    /**
     * it check if starting or end point given are valid or not.
     * @return true if points are valid, false otherwise.
     */
    public boolean check(){
        return (matrix[starting_point_y][starting_point_x] ==0 && matrix[end_point_y][end_point_x] == 0);
    }
    /**
     * getter for map.
     */
    public int [][] getMatrix(){
        return matrix;
    }
    /**
     * getter for column of starting point.
     */
    public int getStartingPoint_x(){
        return starting_point_x;
    }
    /**
     * getter for row of starting point.
     */
    public int getStartingPoint_y(){
        return starting_point_y;
    }
    /**
     * getter for column of end point.
     */
    public int getEndPoint_x(){
        return end_point_x;
    }
    /**
     * getter for row of end point.
     */
    public int getEndPoint_y(){
        return end_point_y;
    }
    /**
     * getter for row number of map.
     */
    public int getRowNum(){
        return rowNum;
    }
    /**
     * getter for column number of map.
     */
    public int getColumnNum(){
        return columnNum;
    }
    /**
     * getter for specified value in map.
     * @param y row number
     * @param x column number
     */
    public int getMatrixValue(int y, int x){
        return matrix[y][x];
    }
    /**
     * getter for filename.
     */
    public String getFileName(){
        return filename;
    }
}