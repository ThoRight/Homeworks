/**
 * @author MuratErbilici
 * @since 03.06.2023
 */

import java.util.*;
import java.io.*;

public class CSE222Graph{
    private CSE222Map map;
    private ArrayList<Vertex> vertices;

    /**
     * constructor to create graph.
     * @param map Map to construct graph.
     */
    public CSE222Graph(CSE222Map map){
        vertices = new ArrayList<Vertex>();
        this.map = map;
        constructGraph();
    }
    
    /**
     * helper method to construct graph. it adds vertices and edges to these vertices according to map.
     */
    private void constructGraph(){
        System.out.printf("Graph for %s is being constructed(total 2 minutes. 1000x1000 map might be longer)......\n", map.getFileName());
        int [][] matrix = map.getMatrix();
        for(int y=0;y<map.getRowNum();++y){
            for(int x=0;x<map.getColumnNum();++x){
                if(matrix[y][x]==0){
                    Vertex vertex = new Vertex(y,x);
                    vertices.add(vertex);
                }
            }
        }
        for(int y=0;y<vertices.size();++y){
            for(int x=y;x<vertices.size();++x){
                if(x!=y && isEdge(vertices.get(y),vertices.get(x))){
                    vertices.get(y).add(vertices.get(x));
                    vertices.get(x).add(vertices.get(y));
                }
            }
        }
    }
    /**
     * checks if two vertices are connected or not.
     * @param v1 first vertex.
     * @param v2 second vertex.
     * @return true if these are connected, false otherwise.
     */
    private boolean isEdge(Vertex v1, Vertex v2){
        if(v1.getY()-v2.getY()<=1 && v1.getY()-v2.getY() >= -1 && v1.getX()-v2.getX()<=1 && v1.getX()-v2.getX() >= -1 ){
            return true;
        }
        return false;
    }
    /**
     * getter for total vertex num.
     */
    public int getNumV(){
        return vertices.size();
    }
    /**
     * getter to find specified vertex in graph.
     * @param y row number that vertex has.
     * @param x column number that vertex has.
     */
    private Vertex findVertex(int y, int x){
        for(int i=0;i<vertices.size();++i){
            if(vertices.get(i).getY()==y && vertices.get(i).getX()==x) return vertices.get(i);
        }
        return null;
    }
    
    /**
     * Actual BFS algorithm to find shortest path.
     * @param source starting vertex.
     * @param destination end vertex.
     * @return shortest path between these vertex.
     */
    private List<Vertex> BFS(Vertex source, Vertex destination){
        Queue<Vertex> queue = new LinkedList<>();
        source.setMinDistance(0);
        queue.add(source);

        while (!queue.isEmpty()){
            Vertex current = queue.poll();
            if(current == destination){
                // Destination reached
                break;
            }
            for(Vertex neighbor : current.getNeighbors()){
                if(neighbor.getMinDistance() == Integer.MAX_VALUE){
                    // we change their value so it is visited anymore.
                    neighbor.setMinDistance(current.getMinDistance()+1);
                    neighbor.setPrevious(current);
                    // Insert its edge into the queue.
                    queue.add(neighbor);
                }
            }
        }
        List<Vertex> path = getPath(destination);
        if(path != null){
            return path;
        }else{
            System.out.printf("No path found from starting vertex to end vertex for %s.\n", map.getFileName());
            return null;
        }
    }

    /**
     * public method to find shortest path using BFS.
     * @return shortest path between starting vertex and end vertex.
     */
    public List<Vertex> findBFSPath(){
        System.out.println("Applying bfs to find the shortest path....");
        resetData();
        Vertex source = findVertex(map.getStartingPoint_y(), map.getStartingPoint_x());
        Vertex destination = findVertex(map.getEndPoint_y(), map.getEndPoint_x());
        return BFS(source, destination);
    }
    
    /**
     * public method to find shortest path using dijkstra.
     * @return shortest path between starting vertex and end vertex.
     */
    public List<Vertex> findDijkstraPath(){
        System.out.println("Applying dijktra to find the shortest path....");
        resetData();
        Vertex source = findVertex(map.getStartingPoint_y(), map.getStartingPoint_x());
        Vertex destination = findVertex(map.getEndPoint_y(), map.getEndPoint_x());
        return dijkstra(source,destination);
    }
    
    /**
     * Actual dijkstra algorithm to find shortest path.
     * @param startVertex starting vertex.
     * @param endVertex end vertex.
     * @return shortest path between these vertex.
     */
    private List<Vertex> dijkstra(Vertex startVertex, Vertex endVertex){
        Set<Vertex> visited = new HashSet<>();
        PriorityQueue<Vertex> pQueue = new PriorityQueue<>();

        startVertex.setMinDistance(0);
        pQueue.add(startVertex);

        while(!pQueue.isEmpty()){
            Vertex currentVertex = pQueue.poll();

            // Add current vertex to visited set
            visited.add(currentVertex);

            if(currentVertex == endVertex){
                // we reached the destination.
                break;
            }
            for(Vertex neighbor : currentVertex.getNeighbors()){
                if(!visited.contains(neighbor)){
                    int edgeWeight = 1; // Assuming all edges weight = 1.
                    int newDistance = currentVertex.getMinDistance() + edgeWeight;
                    if(newDistance < neighbor.getMinDistance()){
                        // Update minimum distance and previous vertex
                        pQueue.remove(neighbor);
                        neighbor.setMinDistance(newDistance);
                        neighbor.setPrevious(currentVertex);
                        pQueue.add(neighbor);
                    }
                }
            }
        }
        List<Vertex> path = getPath(endVertex);
        if(path != null){
            return path;
        }else{
            System.out.printf("No path found from starting vertex to end vertex for %s.\n", map.getFileName());
            return null;
        }
    }
    /**
     * to create path according to end vertex(because we keep previous vertex for each vertex).
     * @param destination end vertex
     * @return shortest path
     */
    private List<Vertex> getPath(Vertex destination){
        if(destination.getMinDistance() == Integer.MAX_VALUE){
            return null;
        }
        List<Vertex> path = new ArrayList<>();
        Vertex current = destination;
    
        while(current != null){
            path.add(current);
            current = current.getPrevious();
        }
    
        Collections.reverse(path);
        return path;
    }
    /**
     * it resets the data before algorithms start.(because in algorithms, each vertex keeps distance and previouse vertex)
     */
    private void resetData(){
        for(int i=0;i<vertices.size();++i){
            vertices.get(i).resetData();
        }
    }



}