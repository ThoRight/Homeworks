import java.util.*;
public class Vertex{
    private int row;
    private int col;
    private List<Vertex> neighbors;
    public int minDistance;
    public Vertex previous;

    public Vertex(int row, int col){
        this.row = row;
        this.col = col;
        this.neighbors = new ArrayList<>();
        minDistance = Integer.MAX_VALUE;
        previous = null;
    }
    public void resetData(){
        previous = null;
        minDistance = Integer.MAX_VALUE;
    }
    public List<Vertex> getNeighbors(){
        return neighbors;
    }
    public void setNeighbors(List<Vertex> neighbors){
        this.neighbors = neighbors;
    }
    public int getY(){
        return row;
    }
    public int getX(){
        return col;
    }
    public void add(Vertex v){
        neighbors.add(v);
    }
    public Vertex getPrevious(){
        return previous;
    }
    public void setPrevious(Vertex v){
        previous = v;
    }
    public void setMinDistance(int value){
        minDistance = value;
    }
    public int getMinDistance(){
        return minDistance;
    }
}