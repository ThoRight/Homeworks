import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;


public class CSE222Map{
    private int starting_point_y;
    private int starting_point_x;
    private int end_point_y;
    private int end_point_x;
    private int [][] matrix;

    public CSE222Map(String filename)throws FileNotFoundException{
        matrix = new int[500][500];
        read_from_file(filename);
        print_input();
      //  convert_png(filename);
    }
    public void read_from_file(String filename)throws FileNotFoundException{
        File file = new File(filename);
        Scanner sc = new Scanner(file);
        Scanner sc2;
        String temp;
        int y=0;
        int x=0;
        for(int i=0;i<2;++i){
            temp = sc.nextLine();
            sc2 = new Scanner(temp);
            sc2.useDelimiter(",");
            if(i==0){
                starting_point_y = Integer.parseInt(sc2.next());
                starting_point_x = Integer.parseInt(sc2.next());
            }
            else{
                end_point_y = Integer.parseInt(sc2.next());
                end_point_x = Integer.parseInt(sc2.next());
            }
        }
        while(sc.hasNextLine()){
            temp = sc.nextLine();
            sc2 = new Scanner(temp);
            sc2.useDelimiter(",");
            x=0;
            while(sc2.hasNextLine()){
                int value = Integer.parseInt(sc2.next());
                if(value == -1) value = 1;
                matrix[y][x] = value;
                ++x;
            }
            ++y;
        }
    }
    public void print_input(){
        System.out.printf("%d,%d\n", starting_point_y, starting_point_x);
        System.out.printf("%d,%d\n", end_point_y, end_point_x);

        for(int i=0;i<3;++i){
            for(int j=0;j<16;++j){
                System.out.printf("%d,", matrix[i][j]);
            }
            System.out.printf("\n");
        }
        System.out.printf("\n%d %d", matrix[starting_point_y][starting_point_x], matrix[end_point_y][end_point_x]);
    }

    public void convert_png(String filename){
        try{
            BufferedImage image = new BufferedImage(500, 500, BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < 500; ++y){
                for (int x = 0; x < 500; ++x){
                    if (matrix[y][x] == 0){
                        image.setRGB(x, y, Color.WHITE.getRGB());
                    } else if(matrix[y][x] == 1){
                        image.setRGB(x, y, Color.LIGHT_GRAY.getRGB());
                    }
                }
            }
        
            Path outputPath = Paths.get("deneme.png");
            ImageIO.write(image, "PNG", outputPath.toFile());
            System.out.println("Image converted successfully.");
        }
        catch(IOException e){

        }
    }
    public int [][] getMatrix(){
        return matrix;
    }
}