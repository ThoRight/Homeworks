import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class TestClass{
    public static void main(String [] args)throws FileNotFoundException{
        CSE222Map testMap = new CSE222Map("map01.txt");
        CSE222Graph testGraph = new CSE222Graph(testMap);
        testGraph.printGraph();
    }
}