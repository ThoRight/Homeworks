import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.*;

public class CSE222Graph{
    private CSE222Map map;
    private ArrayList<Vertex> adjacencyList;

    public CSE222Graph(CSE222Map map){
        adjacencyList = new ArrayList<Vertex>();
        this.map = map;
        constructGraph(map);
    }
    
    private void constructGraph(CSE222Map map){
        System.out.printf("Graph for %s is being constructed......\n", map.getFileName());
        int [][] matrix = map.getMatrix();
        for(int y=0;y<map.getRowNum();++y){
            for(int x=0;x<map.getColumnNum();++x){
                if(matrix[y][x]==0){
                    Vertex vertex = new Vertex(y,x);
                    adjacencyList.add(vertex);
                }
            }
        }
        for(int y=0;y<adjacencyList.size();++y){
            for(int x=y;x<adjacencyList.size();++x){
                if(x!=y && isEdge(adjacencyList.get(y),adjacencyList.get(x))){
                    adjacencyList.get(y).add(adjacencyList.get(x));
                    adjacencyList.get(x).add(adjacencyList.get(y));
                }
            }
        }
    }
    private boolean isEdge(Vertex v1, Vertex v2){
        if(v1.getY()-v2.getY()<=1 && v1.getY()-v2.getY() >= -1 && v1.getX()-v2.getX()<=1 && v1.getX()-v2.getX() >= -1 ){
            //System.out.println("Edge");
            return true;
        }
        return false;
    }
    public void printGraph() {
        System.out.println("<asd>");
        System.out.println(adjacencyList.size());
        for (Vertex vertex : adjacencyList) {
            System.out.print(vertex + " -> ");
            for (Vertex neighbor : vertex.getNeighbors()) {
                System.out.print(neighbor + " ");
            }
            System.out.println();
        }
    }
    public int getNumV(){
        return adjacencyList.size();
    }
    public Vertex findVertex(int y, int x){
        for(int i=0;i<adjacencyList.size();++i){
            if(adjacencyList.get(i).getY()==y && adjacencyList.get(i).getX()==x) return adjacencyList.get(i);
        }
        return null;
    }
    /*
    public List<Vertex> findDijkstraPath(){
        Vertex source = findVertex(map.getStartingPoint_y(),map.getStartingPoint_x());
        Vertex destination = findVertex(map.getEndPoint_y(),map.getEndPoint_x());
        dijkstra(source, destination);
        List<Vertex> shortestPath = getShortestPath(destination);
        return shortestPath;
    }
    private void dijkstra(Vertex source, Vertex destination){
        PriorityQueue<Vertex> queue = new PriorityQueue<>(Comparator.comparingInt(v -> v.getMinDistance()));
        source.setMinDistance(0);
        queue.add(source);
    
        while (!queue.isEmpty()){
            Vertex current = queue.poll();
            if (current == destination) {
                break;
            }
            for (Vertex neighbor : current.getNeighbors()){
                int distance = current.getMinDistance() + 1; // Assuming all edges have a weight of 1
                if (distance < neighbor.getMinDistance()){
                    neighbor.setMinDistance(distance);
                    neighbor.setPrevious(current);
                    queue.add(neighbor);
                }
            }
        }
    } */
    
    public List<Vertex> getShortestPath(Vertex destination){
        List<Vertex> path = new ArrayList<>();
        Vertex current = destination;
    
        while (current != null) {
            path.add(current);
            current = current.getPrevious();
        }
    
        Collections.reverse(path);
        return path;
    }
    public List<Vertex> bfs(Vertex source, Vertex destination){
        Queue<Vertex> queue = new LinkedList<>();
        source.setMinDistance(0);
        queue.add(source);

        while (!queue.isEmpty()) {
            Vertex current = queue.poll();

            if (current == destination) {
                // Destination reached, exit the loop
                break;
            }

            for (Vertex neighbor : current.getNeighbors()) {
                if (neighbor.getMinDistance() == Integer.MAX_VALUE) {
                    // Mark neighbor as identified (color it light gray)
                    neighbor.setMinDistance(current.getMinDistance()+1);
                    neighbor.setPrevious(current);
                    // Insert neighbor into the queue
                    queue.add(neighbor);
                }
            }
        }

        // Retrieve the shortest path
        return getShortestPath(destination);
    }

    public List<Vertex> findBFSPath(){
        System.out.println("Applying bfs to find shortest path....");
        if(map.getMatrixValue(map.getStartingPoint_y(),map.getStartingPoint_x())!=0
        || map.getMatrixValue(map.getEndPoint_y(),map.getEndPoint_x())!=0){
            System.out.printf("Path for %s can't be found because starting or end point is not 0.\n", map.getFileName());
            return new ArrayList<Vertex>();
        }
        else{
            resetData();
            Vertex source = findVertex(map.getStartingPoint_y(), map.getStartingPoint_x());
            Vertex destination = findVertex(map.getEndPoint_y(), map.getEndPoint_x());
            List<Vertex> shortestPath = bfs(source, destination);
            return shortestPath;
        }
        
    }

    public List<Vertex> findDijkstraPath(){
        System.out.println("Applying Dijkstra to find shortest path....");
        if(map.getMatrixValue(map.getStartingPoint_y(),map.getStartingPoint_x())!=0
        || map.getMatrixValue(map.getEndPoint_y(),map.getEndPoint_x())!=0){
            System.out.printf("Path for %s can't be found because starting or end point is not 0.\n", map.getFileName());
            return new ArrayList<Vertex>();
        }
        else{
            resetData();
            Vertex source = findVertex(map.getStartingPoint_y(), map.getStartingPoint_x());
            Vertex destination = findVertex(map.getEndPoint_y(), map.getEndPoint_x());
            return dijkstra(source,destination);
        }
    }
    

    public List<Vertex> dijkstra(Vertex startVertex, Vertex targetVertex) {
        // Step 1: Initialize data structures
        Set<Vertex> visited = new HashSet<>();
        PriorityQueue<Vertex> minHeap = new PriorityQueue<>(Comparator.comparingInt(Vertex::getMinDistance));
        
        // Step 2: Initialize start vertex
        startVertex.setMinDistance(0);
        minHeap.add(startVertex);

        while (!minHeap.isEmpty()) {
            // Step 3: Find vertex with smallest distance in V-S
            Vertex currentVertex = minHeap.poll();

            // Step 4: Add current vertex to visited set
            visited.add(currentVertex);

            // Step 5: Check if we have reached the target vertex
            if (currentVertex == targetVertex) {
                break;
            }

            // Step 6: Update distances of neighboring vertices
            for (Vertex neighbor : currentVertex.getNeighbors()) {
                if (!visited.contains(neighbor)) {
                    int edgeWeight = 1; // Assuming all edges have weight 1
                    int newDistance = currentVertex.getMinDistance() + edgeWeight;

                    if (newDistance < neighbor.getMinDistance()) {
                        // Step 7: Update minimum distance and previous vertex
                        minHeap.remove(neighbor);
                        neighbor.setMinDistance(newDistance);
                        neighbor.setPrevious(currentVertex);
                        minHeap.add(neighbor);
                    }
                }
            }
        }

        // Print the shortest path
        List<Vertex> path = getPath(targetVertex);
        if (path != null) {
            return path;
        } else {
            System.out.printf("No path found from start to target vertex for %s.", map.getFileName());
            return null;
        }
    }

    private List<Vertex> getPath(Vertex targetVertex) {
        if (targetVertex.getMinDistance() == Integer.MAX_VALUE) {
            return null; // No path found
        }

        List<Vertex> path = new ArrayList<>();
        Vertex currentVertex = targetVertex;

        while (currentVertex != null){
            path.add(0, currentVertex);
            currentVertex = currentVertex.getPrevious();
        }

        return path;
    }
    private void resetData(){
        for(int i=0;i<adjacencyList.size();++i){
            adjacencyList.get(i).resetData();
        }
    }



}