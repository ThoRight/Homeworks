import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.*;

public class CSE222Graph{
    private CSE222Map map;
    private ArrayList<Vertex> vertices;
    private int v;

    public CSE222Graph(CSE222Map map){
        vertices = new ArrayList<Vertex>();
        this.map = map;
        v=0;
        constructGraph(map);
    }
        public class Vertex{
            private ArrayList<Integer> edges;
            private int y;
            private int x;
            private int name;
            private Vertex(int name, int y, int x){
                edges = new ArrayList<Integer>(8);
                this.name = name;
                this.y = y;
                this.x = x;
            }
            public int getName(){
                return name;
            }
            public int getx(){
                return x;
            }
            public int gety(){
                return y;
            }
            public int get(int index){
                return edges.get(index);
            }
            public int size(){
                return edges.size();
            }
            public void add(int i){
                edges.add(i);
            }
        }
    private void constructGraph(CSE222Map map){
        int [][] matrix = map.getMatrix();
        for(int y=0;y<500;++y){
            for(int x=0;x<500;++x){
                if(matrix[y][x]==0){
                    Vertex newV = new Vertex(v,y,x);
                    vertices.add(newV);
                    ++v;
                }
            }
        }
        int tempV=0;
        for(int i=0;i<vertices.size();++i){
            for(int j=i+1;j<vertices.size();++j){
                addAllEdges(i,j);
            }
        }
    /*    for(int y=0;y<500;++y){
            for(int x=0;x<500;++x){
                if(matrix[y][x]==0){
                    addAllEdges(matrix,tempV,y,x);
                    ++tempV;
                }
            }
        }*/
    }
    private void addAllEdges(int i,int j){
        if(vertices.get(i).gety()-vertices.get(j).gety()<=1 && vertices.get(i).getx()-vertices.get(j).getx()<=1){
            vertices.get(i).add(vertices.get(j).getName());
            vertices.get(j).add(vertices.get(i).getName());
        }
        
    }
  /*  private void addAllEdges(int [][] matrix, int source, int y, int x){
        if(y-1 >= 0 && matrix[y-1][x]==0){
            int dest = getVertexName(y-1,x);
            addEdge(source,y-1,x);
        }
        if(y+1 < 500 && matrix[y+1][x]==0){
        //    int dest = getVertexName(y+1,x);
            addEdge(source,y+1,x);
        }
        if(x-1 >= 0 && matrix[y][x-1]==0){
         //   int dest = getVertexName(y,x-1);
            addEdge(source,y,x-1);
        }
        if(x+1 < 500 && matrix[y][x+1]==0){
           // int dest = getVertexName(y,x+1);
            addEdge(source,y,x+1);
        }
        if(y-1 >=0 && x-1 >= 0 && matrix[y-1][x-1]==0){
            //int dest = getVertexName(y-1,x-1);
            addEdge(source,y-1,x-1);
        }
        if(y-1 >= 0 && x+1 < 500 && matrix[y-1][x+1]==0){
           // int dest = getVertexName(y-1,x+1);
            addEdge(source,y-1,x+1);
        }
        if(y+1 < 500 && x+1 < 500 && matrix[y+1][x+1]==0){
            //int dest = getVertexName(y+1,x+1);
            addEdge(source,y+1,x+1);
        }
        if(y+1 < 500 && x-1 >= 0 && matrix[y+1][x-1]==0){
            //int dest = getVertexName(y+1,x-1);
            addEdge(source,y+1,x-1);
        }
    }
*/
/*    public void addEdge(int source, int y, int x){
        Vertex v = new Vertex(1,y,x);

    }
    public void addEdge(int source, int des){
        Vertex tempV = getVertex(source);
        graph.get(tempV).add(des);
    }

    public int getVertexName(int y, int x){
        Set<Vertex> keys = graph.keySet();
        for(Vertex key : keys){
            if(key.gety()==y && key.getx()==x){
                return key.getName();
            }
        }
        return -1;
    }
    public Vertex getVertex(int source){
        Set<Vertex> keys = graph.keySet();
        for(Vertex key : keys){
            if(key.getName()==source){
                return key;
            }
        }
        return null;
    }
*/
    public void printGraph(){
        for(int i=0;i<vertices.size();++i){
            System.out.printf("VertexNum: %d\nVertex y: %d\nVertex x: %d\nVertex Neigh: \n",vertices.get(i).getName(),vertices.get(i).gety(),vertices.get(i).getx());
            for(int j=0;j<vertices.get(i).size();++j){
                System.out.printf("%d ", vertices.get(i).get(j));
            }
        }
 /*       Set<Vertex> keys = graph.keySet();
        for(Vertex key: keys){
            System.out.printf("VertexNum: %d\nVertex y: %d\nVertex x: %d\nVertex Neigh: \n",key.getName(),key.gety(),key.getx());
            for(int i=0;i<graph.get(key).size();++i){
                System.out.printf("%d ", graph.get(key).get(i));
            }
        }
*/
    }

}