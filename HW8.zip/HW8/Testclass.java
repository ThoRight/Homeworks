public class Testclass{
    public static void main(String [] args){
        TestCases t1 = new TestCases("Map01.txt",500,500);
        TestCases t2 = new TestCases("Map02.txt",500,500);
        TestCases t3 = new TestCases("Map03.txt",500,500);
        TestCases t4 = new TestCases("Map04.txt",500,500);
        TestCases t5 = new TestCases("Map05.txt",500,500);
        TestCases t6 = new TestCases("Map06.txt",500,500);
        TestCases t7 = new TestCases("Map07.txt",500,500);
        TestCases t8 = new TestCases("Map08.txt",500,500);
        TestCases t9 = new TestCases("Map09.txt",500,500);
        TestCases t10 = new TestCases("Map10.txt",500,500);
        t2.run();
        t3.run();
        t4.run();
        t5.run();
        t6.run();
        t7.run();
        t8.run();
        t9.run();
        t10.run();
    }
}