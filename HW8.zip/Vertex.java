/**
 * @author MuratErbilici
 * @since 03.06.2023
 */

import java.util.*;

public class Vertex implements Comparable<Vertex>{
    private int row;
    private int col;
    private List<Vertex> neighbors;
    public int minDistance;
    public Vertex previous;

    /**
     * constructor to create vertex
     * @param row row number located in map.
     * @param col column number located in map.
     */
    public Vertex(int row, int col){
        this.row = row;
        this.col = col;
        this.neighbors = new ArrayList<>();
        minDistance = Integer.MAX_VALUE;
        previous = null;
    }
    /**
     * to reset previous and minDistance information before algorithms start.
     */
    public void resetData(){
        previous = null;
        minDistance = Integer.MAX_VALUE;
    }
    /**
     * getter for list of adjacents.
     */
    public List<Vertex> getNeighbors(){
        return neighbors;
    }
    /**
     * setter to change neighbors of vertex.
     */
    public void setNeighbors(List<Vertex> neighbors){
        this.neighbors = neighbors;
    }
    /**
     * getter for row number.
     */
    public int getY(){
        return row;
    }
    /**
     * getter for column number.
     */
    public int getX(){
        return col;
    }
    /**
     * it adds vertex to neighbors.
     * @param v vertex we want to add.
     */
    public void add(Vertex v){
        neighbors.add(v);
    }
    /**
     * return for previouse vertex.
     */
    public Vertex getPrevious(){
        return previous;
    }
    /**
     * setter for previous vertex.
     */
    public void setPrevious(Vertex v){
        previous = v;
    }
    /**
     * setter for minDistance.
     */
    public void setMinDistance(int value){
        minDistance = value;
    }
    /**
     * getter for minDistance.
     */
    public int getMinDistance(){
        return minDistance;
    }

    @Override
    public int compareTo(Vertex v){
        if(minDistance <= v.getMinDistance()){
            return -1;
        }
        else{
            return 1;
        }
    }
}