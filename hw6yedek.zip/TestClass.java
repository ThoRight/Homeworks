import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class TestClass{
    public static void main(String [] args){
        String input =  "'Hush, hush' whispered the rushing wind.";
        System.out.printf("input: %s\n", input);
        myMap map = new myMap(input);
        System.out.printf("After Preprocessing: ");
        map.printString();
        map.printMap();
        mergeSort mergeSort = new mergeSort(map);
        System.out.println("After Sortin: \n");
        mergeSort.printSortedMap();

        
        int[] actual = {3,2,4,1,1,1,2,1};
        int[] expected = new int[8];
        mergeSort(actual, actual.length,expected);
        for(int i=0;i<8;++i)
            System.out.printf(" %d ", expected[i]);

    }

    public static void mergeSort(int[] a, int n,int [] last) {
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        int[] l = new int[mid];
        int[] r = new int[n - mid];
    
        for (int i = 0; i < mid; i++) {
            l[i] = a[i];
        }
   /*     System.out.printf("\nL: ");
        for(int i=0;i<mid;++i){
            System.out.printf("%d ", l[i]);
        } */
        for (int i = mid; i < n; i++) {
            r[i - mid] = a[i];
        }
     /*   System.out.printf("\nR: ");
        for(int i=mid;i<n;++i){
            System.out.printf("%d ", r[i-mid]);
        }*/

        mergeSort(l, mid,last);
        mergeSort(r, n - mid,last);
    
        merge(a, l, r, mid, n - mid,last);
    }

    public static void merge(
  int[] a, int[] l, int[] r, int left, int right,int [] last) {
 
    int i = 0, j = 0, k = 0;
 /*   System.out.println("\nL: ");
    for(int c=0;c<l.length;++c){
        System.out.printf("%d ",l[c]);
    }
    System.out.println("\nR: ");
    for(int c=0;c<r.length;++c){
        System.out.printf("%d ",r[c]);
    }
    System.out.printf("\n");*/
    while (i < left && j < right) {
      //  System.out.printf("\nKARŞILART2: %d %d \n",l[i],r[j] );
        if (l[i] <= r[j]) {
            last[k++] = l[i++];
          //  a[k++] = l[i++];
        }
        else {
            last[k++] = r[j++];
         //   a[k++] = r[j++];
        }
    }
    while (i < left) {
        last[k++] = l[i++];
      //  a[k++] = l[i++];
    }
    while (j < right) {
        last[k++] = r[j++];
      //  a[k++] = r[j++];
    }
}

}