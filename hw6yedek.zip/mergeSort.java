import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class mergeSort{
    private myMap originalMap;
    private myMap sortedMap;
    private String [] aux;

    public mergeSort(myMap map){
        this.originalMap = map;
        sortedMap = new myMap();
        sortedMap.setStr(originalMap.getStr());
        sortedMap = originalMap;
        aux = new String[originalMap.getMapSize()];
       // sort(sortedMap,sortedMap.getMapSize());
       sort(sortedMap);
        for(int i=0;i<aux.length;++i){
            System.out.println(aux[i]);
        }
        for(int i=0;i<aux.length;++i){
            sortedMap.put(aux[i],originalMap.getLinkedHashMap().get(aux[i]));
        }
    //    sortedMap.put( "x", sortedMap.getLinkedHashMap().remove( "u" ) );
    }



/*


    public void sort(myMap a, int n){
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        myMap l = new myMap();
        myMap r = new myMap();
    
        for (int i = 0; i < mid; i++){
            l.put(a.getkey(i),a.getinfo(i));
        }
        for (int i = mid; i < n; i++){
            r.put(a.getkey(i),a.getinfo(i));
        }

        sort(l, mid);
        sort(r, n - mid);
    
        merge(a, l, r, mid, n - mid);
    }

    public void merge(
        myMap a, myMap l, myMap r, int left, int right) {
          int i = 0, j = 0, k = 0;
          while (i < left && j < right){
          //  System.out.printf("\nKARŞILART1: %d %d \n",l.getinfo(i).getCount(),r.getinfo(j).getCount() );
              if (l.getinfo(i).getCount() <= r.getinfo(j).getCount()) {
                a.replace(l.getkey(i),l.getinfo(i),k);
                aux[k++] = l.getkey(i++);
              }
              else {
                a.replace(r.getkey(j),r.getinfo(j),k);
                    aux[k++] = r.getkey(j++);
              }
          }
          while (i < left) {
            a.replace(l.getkey(i),l.getinfo(i),k);
            aux[k++] = l.getkey(i++);
          }
          while (j < right) {
            a.replace(r.getkey(j),r.getinfo(j),k);
            aux[k++] = r.getkey(j++);
          }
      }
      
*/





    public void merge(myMap map, myMap leftMap, myMap rightMap){
        int i=0,j=0,k=0;
        while (i < leftMap.getMapSize() && j < rightMap.getMapSize()){
            // Find the smaller and
            // insert it into the output sequence.
            if (leftMap.getinfo(i).getCount() < rightMap.getinfo(j).getCount()){
              //  sortedMap.put(leftMap.getkey(i),leftMap.getinfo(i));
                map.replace(leftMap.getkey(i),leftMap.getinfo(i),k);
                aux[k] = leftMap.getkey(i);
                i++;
                k++;
            }
            else{
            //    sortedMap.put(rightMap.getkey(j),rightMap.getinfo(j));
            map.replace(rightMap.getkey(j),rightMap.getinfo(j),k);    
            aux[k] = rightMap.getkey(j);
                j++;
                k++;
            }
        }
        // assert: one of the sequences has more items to copy.
        // Copy remaining input from left sequence into the output.
        while (i < leftMap.getMapSize()){
           // sortedMap.put(leftMap.getkey(i),leftMap.getinfo(i));
           map.replace(leftMap.getkey(i),leftMap.getinfo(i),k);
           aux[k] = leftMap.getkey(i);
            i++;
            k++;
        }
        // Copy remaining input from right sequence into output.
        while (j < rightMap.getMapSize()){
           // sortedMap.put(rightMap.getkey(j),rightMap.getinfo(j));
           map.replace(rightMap.getkey(j),rightMap.getinfo(j),k);
           aux[k] = rightMap.getkey(j);
            j++;
            k++;
        }
    }

    public void sort(myMap originalMap){
        // A table with one element is sorted already.
        if (originalMap.getMapSize() > 1){
            // Split table into halves.
            int mid = originalMap.getMapSize() / 2;
            myMap leftMap = new myMap();
            myMap rightMap = new myMap();
            mapCopy(originalMap,0,leftMap,mid);
            mapCopy(originalMap,mid,rightMap,originalMap.getMapSize()-mid);
            // Sort the halves.
            sort(leftMap);
            sort(rightMap);
            // Merge the halves.
            merge(originalMap, leftMap, rightMap);
        }
    }
    


/*
   private void sort(int low, int high) {
    // check if low is smaller than high, if not then the array is sorted
    if (low < high) {
        // Get the index of the element which is in the middle
        int middle = low + (high - low) / 2;
        // Sort the left side of the array
        sort(low, middle);
        // Sort the right side of the array
        sort(middle + 1, high);
        // Combine them both
        merge(low, middle, high);
    }
}

private void merge(int low, int middle, int high){
    myMap tempMap = new myMap();
    // Copy both parts into the helper array
    for (int i = low; i <= high; i++){
        tempMap.put(originalMap.getkey(i),originalMap.getinfo(i));
        //helper[i] = numbers[i];
    }

    int i = low;
    int j = middle + 1;
    int k = low;
    // Copy the smallest values from either the left or the right side back
    // to the original array
    while (i <= middle && j <= high){
        System.out.println(i);
        System.out.println(j);
        if (tempMap.getinfo(i).getCount()<= tempMap.getinfo(j).getCount()) {
            aux[k] = tempMap.getkey(i);
            i++;
        } else {
            aux[k] = tempMap.getkey(j);
            j++;
        }
        k++;
    }
    // Copy the rest of the left side of the array into the target array
    while (i <= middle) {
        aux[k] = tempMap.getkey(i);
        k++;
        i++;
    }
    // Since we are sorting in-place any leftover elements from the right side
    // are already at the right position.

}
*/






    public void printSortedMap(){
        sortedMap.printMap();
    }

    public void mapCopy(myMap originalMap, int startIndex, myMap copyMap, int count){
        for(int i=0;i<count;++i){
            copyMap.put(originalMap.getkey(startIndex),originalMap.getinfo(startIndex));
            ++startIndex;
        }
    }
}