import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class info{
    private int count=0;
    private ArrayList<String> words;
    public info(String word){
        words = new ArrayList<String>();
        words.add(word);
        ++count;
    }
    public void push(String word){
        words.add(word);
        ++count;
    }
    public int getCount(){
        return count;
    }
    public void printInfo(){
        System.out.printf("Count: %d - ",count);
        System.out.printf("Words: ");
        System.out.printf("[");
        for(int i=0;i<count;++i){
            if(i!=words.size()-1){
                System.out.printf("%s, ", words.get(i));
            }
            else{
                System.out.printf("%s]\n", words.get(i));
            }
        }
    }




}
