import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class myMap{
    private LinkedHashMap <String, info> map;
    private int mapSize;
    private String str;

    public myMap(String input){
        mapSize = 0;
        map = new LinkedHashMap<String,info>();
        str = preprocessing(input);
        createMap();
    }
    public myMap(){
        mapSize = 0;
        map = new LinkedHashMap<String,info>();
    }
    public void printString(){
        System.out.println(str);
    }
    public String preprocessing(String str){
        String temp = "";
        for(int i=0;i<str.length();++i){
            if(str.charAt(i) >='a' && str.charAt(i) <= 'z'){
                temp+=str.charAt(i);
            }
            else if(str.charAt(i) >= 'A' && str.charAt(i) <= 'Z'){
                char c = str.charAt(i);
                c+=32;
                temp+=c;
            }
            else if(str.charAt(i) == ' '){
                temp+=str.charAt(i);
            }
        }
        return temp;
    }

    public void createMap(){
        ArrayList<String> seperatedWords = divideIntoWords();
        int index=0;
        int alistindex=0;
        boolean isSpace = false;
        for(int i=0;i<str.length();++i){
            if(str.charAt(i)!=' ')
                break;
            ++index;
        }
        for(int i=index;i<str.length();++i){
            String tempStr="";
            tempStr+=str.charAt(i);
            if(str.charAt(i) == ' ') isSpace = true;
            else if(isSpace){
                ++alistindex;
                isSpace=false;
            }
            if(map.containsKey(tempStr)){
                info info = map.get(tempStr);
                info.push(seperatedWords.get(alistindex));
            }
            else if(str.charAt(i) != ' '){
                info info = new info(seperatedWords.get(alistindex));
                String temp ="";
                temp+=str.charAt(i);
                map.put(temp,info);
                ++mapSize;
            }
        }
    }
    public void printMap(){
        Set<String> keys = map.keySet();
        for(String key : keys){
            System.out.printf("Letter: %s - ", key);
            info info = map.get(key);
            info.printInfo();
        }
    }

    public ArrayList<String> divideIntoWords(){
        ArrayList<String> tempList = new ArrayList<String>();
        String tempStr = "";
        for(int i=0;i<str.length();++i){
            if(str.charAt(i) != ' '){
                tempStr += str.charAt(i);
            }
            if(str.charAt(i) == ' ' && tempStr.length()!=0 || i==str.length()-1 && tempStr.length()!=0){
                tempList.add(tempStr);
                tempStr = "";
            }
        }
        return tempList;
    }

    public int getMapSize(){
        return mapSize;
    }

    public String getStr(){
        return str;
    }
    public LinkedHashMap<String,info> getLinkedHashMap(){
        return map;
    }

    public void put(String str, info info){
        map.put(str,info);
        ++mapSize;
    }
    public String getkey(int index){
        int i=0;
        Set<String> keys = map.keySet();
        for(String key : keys){
            if(i==index) return key;
            ++i;
        }
        return null;
    }
    public info getinfo(int index){
        int i=0;
        Set<String> keys = map.keySet();
        for(String key : keys){
            if(i==index){
                info tempinfo = map.get(key);
                return tempinfo;
            }
            ++i;
        }
        return null;
    }
    public void setStr(String str){
        this.str = str;
    }

    public void replace(String key, info value, int index){
        myMap newMap = new myMap();
        newMap.setStr(str);
        for(int i=0;i<mapSize;++i){
            if(i==index) newMap.put(key,value);
            else newMap.put(this.getkey(i),this.getinfo(i));
        }
        map = newMap.getLinkedHashMap();
        mapSize = newMap.getMapSize();
    }


}
