/**
 * @author MuratErbilici
 * @since 10.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * Test Class to test sort algorithm for best, avg and worst case.
 */
public class TestClass{
    /**
     * Main method.
     * There are spaces in inputs to make reading maps easier.
     */
    public static void main(String [] args){
    // ----------------- Bubble Sort ---------------------------
        String bubbleBest =  "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh"; // already sorted
        String bubbleAvg = "dddd a ccc bb ggggggg hhhhhhhh eeeee ffffff"; // between best and worst
        String bubbleWorst = "hhhhhhhh ggggggg ffffff eeeee dddd ccc bb a"; // already reverse sorted

        myMap map1 = new myMap(bubbleBest);
        myMap map2 = new myMap(bubbleAvg);
        myMap map3 = new myMap(bubbleWorst);

        bubbleSort bubbleSort = new bubbleSort();

        System.out.println("\n\n\nBubble Sort........");
        
        System.out.printf("Best Case input: %s\n",bubbleBest);
        System.out.printf("Original String: %s\n", bubbleBest);
        System.out.printf("Preprocessed String: ");
        map1.printString();
        System.out.println("The original (unsorted) map:");
        map1.printMap();
        bubbleSort.sort(map1);
        System.out.println("The sorted map:");
        bubbleSort.printSortedMap();

        System.out.printf("Avg Case input: %s\n", bubbleAvg);
        System.out.printf("Original String: %s\n", bubbleAvg);
        System.out.printf("Preprocessed String: ");
        map2.printString();
        System.out.println("The original (unsorted) map:");
        map2.printMap();
        bubbleSort.sort(map2);
        System.out.println("The sorted map:");
        bubbleSort.printSortedMap();

        System.out.printf("Worst Case input: %s\n", bubbleWorst);
        System.out.printf("Original String: %s\n", bubbleWorst);
        System.out.printf("Preprocessed String: ");
        map3.printString();
        System.out.println("The original (unsorted) map:");
        map3.printMap();
        bubbleSort.sort(map3);
        System.out.println("The sorted map:");
        bubbleSort.printSortedMap();

        // ----------------- Selection Sort ---------------------------
        String selectionBest =  "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh"; // already sorted
        String selectionAvg = "dddd a ccc bb ggggggg hhhhhhhh ffffff eeeee"; // between best and worst
        String selectionWorst = "hhhhhhhh ggggggg ffffff eeeee dddd ccc bb a"; // already reverse sorted

        myMap map4 = new myMap(selectionBest);
        myMap map5 = new myMap(selectionAvg);
        myMap map6 = new myMap(selectionWorst);

        selectionSort selectionSort = new selectionSort();

        System.out.println("\n\n\nSelection Sort........");
        
        System.out.printf("Best Case input: %s\n",selectionBest);
        System.out.printf("Original String: %s\n", selectionBest);
        System.out.printf("Preprocessed String: ");
        map4.printString();
        System.out.println("The original (unsorted) map:");
        map4.printMap();
        selectionSort.sort(map4);
        System.out.println("The sorted map:");
        selectionSort.printSortedMap();

        System.out.printf("Avg Case input: %s\n", selectionAvg);
        System.out.printf("Original String: %s\n", selectionAvg);
        System.out.printf("Preprocessed String: ");
        map5.printString();
        System.out.println("The original (unsorted) map:");
        map5.printMap();
        selectionSort.sort(map5);
        System.out.println("The sorted map:");
        selectionSort.printSortedMap();

        System.out.printf("Worst Case input: %s\n", selectionWorst);
        System.out.printf("Original String: %s\n", selectionWorst);
        System.out.printf("Preprocessed String: ");
        map6.printString();
        System.out.println("The original (unsorted) map:");
        map6.printMap();
        selectionSort.sort(map6);
        System.out.println("The sorted map:");
        selectionSort.printSortedMap();
     
        // ----------------- Insertion Sort ---------------------------
        String insertionBest =  "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh"; // already sorted
        String insertionAvg = "dddd a ccc bb ggggggg hhhhhhhh ffffff eeeee"; // between best and worst
        String insertionWorst = "hhhhhhhh ggggggg ffffff eeeee dddd ccc bb a"; // already reverse sorted

        myMap map7 = new myMap(insertionBest);
        myMap map8 = new myMap(insertionAvg);
        myMap map9 = new myMap(insertionWorst);

        insertionSort insertionSort = new insertionSort();

        System.out.println("\n\n\nInsertion Sort........");
        
        System.out.printf("Best Case input: %s\n",insertionBest);
        System.out.printf("Original String: %s\n", insertionBest);
        System.out.printf("Preprocessed String: ");
        map7.printString();
        System.out.println("The original (unsorted) map:");
        map7.printMap();
        insertionSort.sort(map7);
        System.out.println("The sorted map:");
        insertionSort.printSortedMap();

        System.out.printf("Avg Case input: %s\n", insertionAvg);
        System.out.printf("Original String: %s\n", insertionAvg);
        System.out.printf("Preprocessed String: ");
        map8.printString();
        System.out.println("The original (unsorted) map:");
        map8.printMap();
        insertionSort.sort(map8);
        System.out.println("The sorted map:");
        insertionSort.printSortedMap();

        System.out.printf("Worst Case input: %s\n", insertionWorst);
        System.out.printf("Original String: %s\n", insertionWorst);
        System.out.printf("Preprocessed String: ");
        map9.printString();
        System.out.println("The original (unsorted) map:");
        map9.printMap();
        insertionSort.sort(map9);
        System.out.println("The sorted map:");
        insertionSort.printSortedMap();

        // ----------------- Quick Sort ---------------------------
        String quickBest =  "a hhhhhhhh bb ffffff ggggggg ccc dddd eeeee  "; // randomly (pivot should be middle or near to the middle).
        String quickAvg = "dddd eeeee ccc bb ggggggg hhhhhhhh ffffff a"; // neither randomly nor sorted or reverse sorted.
        String quickWorst = "hhhhhhhh ggggggg ffffff eeeee dddd ccc bb a"; // already sorted or reverse sorted.

        myMap map10 = new myMap(quickBest);
        myMap map11 = new myMap(quickAvg);
        myMap map12 = new myMap(quickWorst);

        quickSort quickSort = new quickSort();

        System.out.println("\n\n\nQuick Sort........");
        
        System.out.printf("Best Case input: %s\n",quickBest);
        System.out.printf("Original String: %s\n", quickBest);
        System.out.printf("Preprocessed String: ");
        map10.printString();
        System.out.println("The original (unsorted) map:");
        map10.printMap();
        quickSort.sort(map10);
        System.out.println("The sorted map:");
        quickSort.printSortedMap();

        System.out.printf("Avg Case input: %s\n", quickAvg);
        System.out.printf("Original String: %s\n", quickAvg);
        System.out.printf("Preprocessed String: ");
        map11.printString();
        System.out.println("The original (unsorted) map:");
        map11.printMap();
        quickSort.sort(map11);
        System.out.println("The sorted map:");
        quickSort.printSortedMap();

        System.out.printf("Worst Case input: %s\n", quickWorst);
        System.out.printf("Original String: %s\n", quickWorst);
        System.out.printf("Preprocessed String: ");
        map12.printString();
        System.out.println("The original (unsorted) map:");
        map12.printMap();
        quickSort.sort(map12);
        System.out.println("The sorted map:");
        quickSort.printSortedMap();

        // ----------------- Merge Sort ---------------------------
        String mergeBest =  "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh"; // already sorted
        String mergeAvg = "dddd a ccc bb ggggggg hhhhhhhh ffffff eeeee";  // neither already sorted nor the case having most operation.
        String mergeWorst = "eeeee a ggggggg ccc ffffff bb hhhhhhhh dddd"; // the case having most operation

        myMap map13 = new myMap(mergeBest);
        myMap map14 = new myMap(mergeAvg);
        myMap map15 = new myMap(mergeWorst);

        mergeSort mergeSort = new mergeSort();

        System.out.println("\n\n\nMerge Sort........");
        
        System.out.printf("Best Case input: %s\n", mergeBest);
        System.out.printf("Original String: %s\n", mergeBest);
        System.out.printf("Preprocessed String: ");
        map13.printString();
        System.out.println("The original (unsorted) map:");
        map13.printMap();
        mergeSort.sort(map13);
        System.out.println("The sorted map:");
        mergeSort.printSortedMap();

        System.out.printf("Avg Case input: %s\n", mergeAvg);
        System.out.printf("Original String: %s\n", mergeAvg);
        System.out.printf("Preprocessed String: ");
        map14.printString();
        System.out.println("The original (unsorted) map:");
        map14.printMap();
        mergeSort.sort(map14);
        System.out.println("The sorted map:");
        mergeSort.printSortedMap();

        System.out.printf("Worst Case input: %s\n", mergeWorst);
        System.out.printf("Original String: %s\n", mergeWorst);
        System.out.printf("Preprocessed String: ");
        map15.printString();
        System.out.println("The original (unsorted) map:");
        map15.printMap();
        mergeSort.sort(map15);
        System.out.println("The sorted map:");
        mergeSort.printSortedMap();



    }

}