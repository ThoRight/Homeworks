/**
 * @author MuratErbilici
 * @since 14.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;
 
public class selectionSort{
    private myMap originalMap;
    private myMap sortedMap;
    private String [] aux;

    /** 
     * no parameter constructor.
     * it is only to create myMap object(originalMap).
     */
    public selectionSort(){
        originalMap = new myMap();
    }

    /**
     * to start sort operation in main.
     * it is to use it in main class eaiser. Because it has only one parameter.
     * @param map myMap object to assign originalMap.
     */
    public void sort(myMap map){
        aux=null;
        sortedMap=null;
        originalMap = map;
        sortedMap = new myMap();
        sortedMap.setStr(originalMap.getStr());
        aux = new String[originalMap.getMapSize()];
        Set<String> keys = originalMap.getLinkedHashMap().keySet();
        keys.toArray(aux);
        int avgTime = 0;
        String [] tempaux = aux;
        // tempaux and for loop are only to repeat sorting operation to take more accurate result by taking average.
        for(int i=0;i<50;++i){
            aux = tempaux;
            long start = System.nanoTime();
            selectionSortOperation(aux);
            long finish = System.nanoTime();
            long timeElapsed = finish - start;
            avgTime+=timeElapsed;
        }
        avgTime/=50;
        createSortedMap(aux);
        System.out.println("Map Has been sorted.");
        System.out.println("Running time: "+avgTime+" ns");
    }

    /**
     * Actual selection sort algorithm
     * @param aux keys' array.
     */
    private void selectionSortOperation(String [] aux){
        int index;
        for(int i=0;i<aux.length;++i){
            index = i;
            for(int j=i+1;j<aux.length;++j){
                if(originalMap.get(aux[index]).getCount() > originalMap.get(aux[j]).getCount()){
                    index = j;
                }
            }
            String temp = aux[i];
            aux[i] = aux[index];
            aux[index] = temp;
        }
    }

    /**
     * After selection sort operation, to create map according to aux array.
     * @param aux keys' array.
     */
    private void createSortedMap(String [] aux){
        for(int i=0;i<aux.length;++i){
            sortedMap.put(aux[i],originalMap.get(aux[i]));
        }
    }
 
    /**
     * to print sortedMap by using method of myMap.
     */
    public void printSortedMap(){
        sortedMap.printMap();
    }
 
    /**
     * getter for sortedMap.
     */
    public myMap getsortedMap(){
        return sortedMap;
    }
 
    /**
     * getter for originalMap.
     */
    public myMap getoriginalMap(){
        return originalMap;
    }
 
     
}