/**
 * @author MuratErbilici
 * @since 14.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;
public class quickSort{
 
    private myMap originalMap;
    private myMap sortedMap;
    private String [] aux;
 
    /** 
     * no parameter constructor.
     * it is only to create myMap object(originalMap).
     */
    public quickSort(){
        originalMap = new myMap();
    }
    
    /**
     * to start sort operation in main.
     * it is to use it in main class eaiser. Because it has only one parameter.
     * @param map myMap object to assign originalMap.
     */
    public void sort(myMap map){
        aux=null;
        sortedMap=null;
        originalMap = map;
        sortedMap = new myMap();
        sortedMap.setStr(originalMap.getStr());
        aux = new String[originalMap.getMapSize()];
        Set<String> keys = originalMap.getLinkedHashMap().keySet();
        keys.toArray(aux);
        int avgTime = 0;
        String [] tempaux = aux;
        // tempaux and for loop are only to repeat sorting operation to take more accurate result by taking average.
        for(int i=0;i<50;++i){
            aux = tempaux;
            long start = System.nanoTime();
            quickSortOperation(aux);
            long finish = System.nanoTime();
            long timeElapsed = finish - start;
            avgTime+=timeElapsed;
        }
        avgTime/=50;
        createSortedMap(aux);
        System.out.println("Map Has been sorted.");
        System.out.println("Running time: "+avgTime+" ns");
    }

    /**
     * quick sort algorithm.
     * @param aux keys' array.
     */
    public void quickSortOperation(String [] aux){
        quickSort(aux,0,aux.length - 1);
    }

    /**
     * quick sort algorithm.
     * @param aux keys' array.
     * @param first first index of array.(lower bound)
     * @param last last index of array.(higher bound)
     */
    private void quickSort(String [] aux, int first, int last){
        if (first < last){
            int pivIndex = partition(aux, first, last);
            quickSort(aux, first, pivIndex - 1);
            quickSort(aux, pivIndex + 1, last);
        }
    }
    /**
     * quick sort algorithm.
     * @param aux keys' array.
     * @param low first index of array.(lower bound)
     * @param high last index of array.(higher bound)
     */
    private int partition(String [] aux, int low, int high){
        String pivot = aux[high];
        int i = (low - 1);
 
        for(int j=low;j<=high-1;j++){
            if(originalMap.get(aux[j]).getCount() < originalMap.get(pivot).getCount()){
                i++;
                swap(aux, i, j);
            }
        }
        swap(aux, i + 1, high);
        return(i + 1);
    }
    /**
     * to swap two elements of array.
     * @param aux keys' array
     * @param i first index to swap.
     * @param j second index to swap.
     */
    private void swap(String [] aux, int i, int j){
        String temp = aux[i];
        aux[i] = aux[j];
        aux[j] = temp;
    }

    
    
    /**
     * After quick sort operation, to create map according to aux array.
     * @param aux keys' array.
     */
    private void createSortedMap(String [] aux){
        for(int i=0;i<aux.length;++i){
            sortedMap.put(aux[i],originalMap.get(aux[i]));
        }
    }
 
    /**
     * to print sortedMap by using method of myMap.
     */
    public void printSortedMap(){
        sortedMap.printMap();
    }
 
    /**
     * getter for sortedMap.
     */
    public myMap getsortedMap(){
        return sortedMap;
    }
 
    /**
     * getter for originalMap.
     */
    public myMap getoriginalMap(){
        return originalMap;
    }
 
}