/**
 * @author MuratErbilici
 * @since 10.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class mergeSort{
    private myMap originalMap;
    private myMap sortedMap;
    private String [] aux;

    /** 
     * no parameter constructor.
     * it is only to create myMap object(originalMap).
     */
    public mergeSort(){
        originalMap = new myMap();
    }

    /**
     * to start sort operation in main.
     * it is to use it in main class eaiser. Because it has only one parameter.
     * @param map myMap object to assign originalMap.
     */
    public void sort(myMap map){
        aux=null;
        sortedMap=null;
        originalMap = map;
        sortedMap = new myMap();
        sortedMap.setStr(originalMap.getStr());
        aux = new String[originalMap.getMapSize()];
        Set<String> keys = originalMap.getLinkedHashMap().keySet();
        keys.toArray(aux);
        int avgTime = 0;
        String [] tempaux = aux;
        // tempaux and for loop are only to repeat sorting operation to take more accurate result by taking average.
        for(int i=0;i<50;++i){
            aux = tempaux;
            long start = System.nanoTime();
            mergeSortRec(aux);
            long finish = System.nanoTime();
            long timeElapsed = finish - start;
            avgTime+=timeElapsed;
        }
        avgTime/=50;
        createSortedMap(aux);
        System.out.println("Map Has been sorted.");
        System.out.println("Running time: "+avgTime+" ns");
    }

    /**
     * Actual part of merge sort.
     * it is basic merge sort algorithm, the difference is that this algorithm works with count number of info which is values of key according to keys in aux[].
     * @param aux keys' array.
     */
    private void mergeSortRec(String [] aux){
        if (aux.length > 1){
            int halfSize = aux.length / 2;
            String [] leftAux = new String[halfSize];
            String [] rightAux = new String[aux.length - halfSize];
            for(int i=0;i<halfSize;++i){
                leftAux[i] = aux[i];
            }
            for(int i=0;i<aux.length-halfSize;++i){
                rightAux[i] = aux[i+halfSize];
            }
            mergeSortRec(leftAux);
            mergeSortRec(rightAux);
            merge(aux, leftAux, rightAux);
        }
    }

    /**
     * to merge arrays in desired order.
     * @param sortedAux sorted keys' array.
     * @param lefAux left part of aux.
     * @param rightAux right part of aux.
     */
    private void merge(String [] sortedAux, String [] leftAux, String [] rightAux){ 
        int i = 0; 
        int j = 0; 
        int k = 0; 
        while (i < leftAux.length && j < rightAux.length){
            if (originalMap.get(leftAux[i]).getCount() <= originalMap.get(rightAux[j]).getCount()){
                sortedAux[k] = leftAux[i];
                ++k;
                ++i;
            }
            else{
                sortedAux[k] = rightAux[j];
                ++k;
                ++j;
            }
        }
        
        //to fill rest of them.
        while (i < leftAux.length){
            sortedAux[k] = leftAux[i];
            ++k;
            ++i;
        }
        //to fill rest of them.
        while (j < rightAux.length){
            sortedAux[k] = rightAux[j];
            ++k;
            ++j;
        }
    }

    /**
     * After merge sort operation, to create map according to aux array.
     * @param aux keys' array.
     */
    private void createSortedMap(String [] aux){
        for(int i=0;i<aux.length;++i){
            sortedMap.put(aux[i],originalMap.get(aux[i]));
        }
    }

    /**
     * to print sortedMap by using method of myMap.
     */
    public void printSortedMap(){
        sortedMap.printMap();
    }

    /**
     * getter for sortedMap.
     */
    public myMap getsortedMap(){
        return sortedMap;
    }

    /**
     * getter for originalMap.
     */
    public myMap getoriginalMap(){
        return originalMap;
    }

    
}