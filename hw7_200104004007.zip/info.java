/**
 * @author MuratErbilici
 * @since 10.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class info{
    private int count=0;
    private ArrayList<String> words;

    /**
     * Constructor with word.
     */
    public info(String word){
        words = new ArrayList<String>();
        words.add(word);
        ++count;
    }
    /**
     * to add the word to words list.
     */
    public void push(String word){
        words.add(word);
        ++count;
    }
    /**
     * getter for count.
     */
    public int getCount(){
        return count;
    }
    /**
     * to print count and words.
     */
    public void printInfo(){
        System.out.printf("Count: %d - ",count);
        System.out.printf("Words: ");
        System.out.printf("[");
        for(int i=0;i<count;++i){
            if(i!=words.size()-1){
                System.out.printf("%s, ", words.get(i));
            }
            else{
                System.out.printf("%s]\n", words.get(i));
            }
        }
    }




}
