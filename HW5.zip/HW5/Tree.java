import javax.swing.*;  
import javax.swing.tree.DefaultMutableTreeNode; 
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Stack;

public class Tree{
    private JTree jt;
    private JFrame f;
    private String [][] dataFromFile;
    private int lineSize=0;
    private int lineCapacity=10;
    private int columnSize=0;
    private int columnCapacity=10;
    private DefaultMutableTreeNode root;
    int recursionStep=1;
    Tree() throws FileNotFoundException{
        dataFromFile = new String[lineCapacity][columnCapacity];
        getdata("tree2.txt");
        f = new JFrame("1. Tree");
        root = new DefaultMutableTreeNode("Root");
        DefaultMutableTreeNode newNode = null;
        DefaultMutableTreeNode newNode2 = null;
        boolean check=false;
        for(int i=0;i<dataFromFile.length;++i){
            check = isSame(root,dataFromFile[i][0]);
            if(dataFromFile[i][0] != null && check == false){
                newNode = new DefaultMutableTreeNode(dataFromFile[i][0]);
                root.add(newNode);
            }
            else if(dataFromFile[i][0] != null && check == true){
                newNode = searchNode(root,dataFromFile[i][0]);
            }
            for(int j=1;j<dataFromFile[i].length;++j){
                check = isSame(newNode,dataFromFile[i][j]);
                if(dataFromFile[i][j] != null && check == false){
                    newNode2 = new DefaultMutableTreeNode(dataFromFile[i][j]);
                    newNode.add(newNode2);
                    newNode = searchNode(newNode,dataFromFile[i][j]);
                }
                else if(dataFromFile[i][j] != null && check == true){
                    newNode = searchNode(newNode,dataFromFile[i][j]);
                }
            }
        }
        jt=new JTree(root);
        f.add(jt);
        f.setSize(200,600);

        f.setVisible(true);
        
    }

    public void getdata(String filename) throws FileNotFoundException{
        File file = new File(filename);
        Scanner sc = new Scanner(file);
        int tempcolumnsize = columnSize;
        while (sc.hasNextLine()){
            String temp = sc.nextLine();
            Scanner scanner = new Scanner(temp);
            scanner.useDelimiter(";");
            while(scanner.hasNextLine()){
                dataFromFile[lineSize][tempcolumnsize] = scanner.next();
                ++tempcolumnsize;
                if(tempcolumnsize==columnCapacity){
                    resizeColumnCapacity();
                }
            }
            tempcolumnsize = 0;
            ++lineSize;
            if(lineSize==lineCapacity){
                resizeLineCapacity();
            }
        }
        
    }
    private void resizeLineCapacity(){
        String [][] temp = new String[lineCapacity*2][columnCapacity];
        for(int i=0;i<lineCapacity;++i){
            for(int j=0;j<columnCapacity;++j){
                temp[i][j] = dataFromFile[i][j];
            }
        }
        dataFromFile = temp;
        lineCapacity = lineCapacity*2;
    }
    private void resizeColumnCapacity(){
        String [][] temp = new String[lineCapacity][columnCapacity*2];
        for(int i=0;i<lineCapacity;++i){
            for(int j=0;j<columnCapacity;++j){
                temp[i][j] = dataFromFile[i][j];
            }
        }
        dataFromFile = temp;
        columnCapacity = columnCapacity*2;
    }

    public boolean isSame(DefaultMutableTreeNode root, String str){
        if(str == null){
            return false;
        }
        for(int i=0;i<root.getChildCount();++i){
            if(str.equals(root.getChildAt(i).toString())) return true;
        }
        return false;
    }

    public DefaultMutableTreeNode searchNode(DefaultMutableTreeNode root, String str){
        for(int i=0;i<root.getChildCount();++i){
            if(str.equals(root.getChildAt(i).toString())) return (DefaultMutableTreeNode)root.getChildAt(i); 
        }
        return null;
    }

    public void BFSsearch(String str){
        System.out.printf("Using BFS to find '%s' in the tree...\n", str);
        Queue<DefaultMutableTreeNode> q = new LinkedList<DefaultMutableTreeNode>();
        DefaultMutableTreeNode tempNode;
        int step = 1;
        boolean found = false;
        q.add(root);
        while(!q.isEmpty()){
            tempNode = q.poll();
            System.out.printf("Step %d -> %s", step, tempNode.toString());
            if(str.equals(tempNode.toString())){
                found = true;
                break;
            }
            else{
                System.out.printf("\n");
            }
            for(int i=0;i<tempNode.getChildCount();++i){
                q.add((DefaultMutableTreeNode)tempNode.getChildAt(i));
            }
            ++step;
        }
        if(found) System.out.println(" (Found!)");
        else System.out.println("Not Found.");
    }

    public void DFSsearch(String str){
        System.out.printf("Using DFS to find '%s' in the tree...\n", str);
        Stack<DefaultMutableTreeNode> q = new Stack<DefaultMutableTreeNode>();
        DefaultMutableTreeNode tempNode;
        int step = 1;
        boolean found = false;
        q.push(root);
        while(!q.isEmpty()){
            tempNode = q.pop();
            System.out.printf("Step %d -> %s", step, tempNode.toString());
            if(str.equals(tempNode.toString())){
                found = true;
                break;
            }
            else{
                System.out.printf("\n");
            }
            for(int i=0;i<tempNode.getChildCount();++i){
                q.push((DefaultMutableTreeNode)tempNode.getChildAt(i));
            }
            ++step;
        }
        if(found) System.out.println(" (Found!)");
        else System.out.println("Not Found.");
    }

    public void postOrderFind(DefaultMutableTreeNode root, String str, boolean found){
        if(root == null || found == true);
        else if(root.getChildCount()==0){
            System.out.println(root.toString());
            if(str.equals(root.toString())){
                System.out.println(" (Found!)");
                found = true;
            }
        }
        else{
            for(int i=0;i<root.getChildCount();++i){
                if(str.equals(root.toString())) break;
                postOrderFind((DefaultMutableTreeNode)root.getChildAt(i),str,found);
            }
            System.out.print(root.toString());
            if(str.equals(root.toString())){
                found = true;
                System.out.println(" (Found!)");
            }
            else System.out.printf("\n");
        }
    }

    public boolean postOrderFindRec(DefaultMutableTreeNode root, String str, int stepNum){
        if(root==null) return false;
        boolean found = false;
        if(str.equals(root.toString())) found = true;
        else{
            for(int i=0;i<root.getChildCount();++i){
                found = postOrderFindRec((DefaultMutableTreeNode)root.getChildAt(i),str,stepNum+1);
                if(found) break;
            }
            if(found) System.out.println(stepNum);
            
        }
        return found;
    }
    public void moveOperation(){
        int size=0;
        int cap = columnCapacity;
        String [] location = new String[cap];
        String destination;
        System.out.println("Enter the location that you want to move with comma and without space between them.(For example: 2022,CSE321,Lecture1)");
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();

        System.out.println("Enter the destination year that you want to move(For example: 2023)");
        sc = new Scanner(System.in);
        destination = sc.nextLine();

        Scanner scanner = new Scanner(input);
        scanner.useDelimiter(",");
        while(scanner.hasNextLine()){
            location[size] = scanner.next();
            ++size;
            if(size==cap){
                resizeLocationCapacity(location,cap);
                cap*=2;
            }
        }
        DefaultMutableTreeNode movedNode = root;
        DefaultMutableTreeNode preNode = root;
        DefaultMutableTreeNode preNode2 = root;
        boolean flag=true;
        for(int i=0;i<size;++i){
            preNode2 = preNode;
            preNode = movedNode;
            movedNode = searchNode(movedNode,location[i]);
            if(movedNode == null){
                flag=false;
                noTreeError(location,size);
                break;
            }
        }
        if(flag){
            System.out.printf("Moved ");
            printMovedNode(location,size);
            System.out.printf(" to %s.\n", destination);
            preNode.remove(movedNode);
            moveNode(location,size,movedNode,destination);
            
            if(preNode.getChildCount()==0 && preNode != root){
                preNode2.remove(preNode);
            }
        }
        f.remove(jt);
        jt=new JTree(root);
        f.add(jt);
        f.setSize(200,600);
        f.setVisible(true);

    }
    public void resizeLocationCapacity(String [] str, int cap){
        String [] tempStr = new String[cap*2];
        for(int i=0;i<cap;++i){
            tempStr[i] = str[i];
        }
        str = tempStr;
        cap*=2;
    }

    public void noTreeError(String [] location, int size){
        System.out.printf("Cannot move ");
        for(int i=0;i<size;++i){
            if(i!=size-1){
                System.out.printf("%s->",location[i]);
            }
            else{
                System.out.printf("%s",location[i]);
            }
        }
        System.out.println(" Because it doesn't exist in the tree.");
    }
    public void printMovedNode(String [] location, int size){
        for(int i=0;i<size;++i){
            if(i!=size-1){
                System.out.printf("%s->",location[i]);
            }
            else{
                System.out.printf("%s",location[i]);
            }
        }
    }

    public void printOverwrittenNode(String [] location, int size, String destination){
        System.out.printf("%s->",destination);
        for(int i=1;i<size;++i){
            if(i!=size-1){
                System.out.printf("%s->",location[i]);
            }
            else{
                System.out.printf("%s",location[i]);
            }
        }
    }

    public void moveNode(String [] location, int size, DefaultMutableTreeNode movedNode, String destination){
        DefaultMutableTreeNode destNode = root;
        DefaultMutableTreeNode preNode = root;
        DefaultMutableTreeNode tempNode = root;
        destNode = searchNode(root,destination);
        if(destNode==null){
            for(int i=0;i<size-1;++i){
                if(i==0){
                    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(destination);
                    tempNode.add(newNode);
                    tempNode = newNode;
                }
                else{
                    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(location[i]);
                    tempNode.add(newNode);
                    tempNode = newNode;
                }
            }
            tempNode.add(movedNode);
        }
        else{
            for(int i=1;i<size;++i){
                preNode = destNode;
                destNode = searchNode(destNode,location[i]);
                if(destNode != null && i == size-1){
                    preNode.remove(destNode);
                    preNode.add(movedNode);
                    printOverwrittenNode(location,size,destination);
                    System.out.println(" has been overwritten.");
                }
                else if(destNode == null){
                    for(int j=i;j<size-1;++j){
                        DefaultMutableTreeNode tnode = new DefaultMutableTreeNode(location[j]);
                        preNode.add(tnode);
                        preNode = tnode;
                    }
                    preNode.add(movedNode);
                    break;
                }
            }
        }
    }

    public void menu(){
        boolean loop=true;
        while(loop){
            System.out.println("Please enter the number:");
            System.out.println("1. Search with BFS. (PART B)");
            System.out.println("2. Search with DFS. (PART C)");
            System.out.println("3. Search with post order traversal algorithm. (PART D)");
            System.out.println("4. Move node. (PART E)");
            System.out.println("5. Quit.");
            Scanner sc = new Scanner(System.in);
            String input = sc.nextLine();
            if(input.length() != 1){
                System.out.println("Please enter proper input.");
            }
            else{
                switch(input.charAt(0)){
                    case '1':
                        System.out.print("Enter the node name to be searched: ");
                        sc = new Scanner(System.in);
                        input = sc.nextLine();
                        BFSsearch(input);
                        break;
                    case '2':
                        System.out.print("Enter the node name to be searched: ");
                        sc = new Scanner(System.in);
                        input = sc.nextLine();
                        DFSsearch(input);
                        break;
                    case '3': ;
                        break;
                    case '4':
                        moveOperation();
                        break;
                    case '5':
                        System.out.println("Quitting.....");
                        loop = false;
                        break;
                    default:
                        System.out.println("Please enter proper input.");
                        break;
                }
            }
        }
        f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
    }


}