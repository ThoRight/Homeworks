/**
 * @author MuratErbilici
 * @since 10.05.2023
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public class TestClass{
    /**
     * main method to test classes.
     */
    public static void main(String [] args){
        String input =  "Buzzing bees buzz.";
        String input2 = "'Hush, hush!' whispered the rushing wind.";

        myMap map = new myMap(input);
        myMap map2 = new myMap(input2);
        mergeSort mergeSort = new mergeSort();
        boolean check = map.checkInput(map.preprocessing(input));
        if(check){
            System.out.printf("Original String: %s\n", input);
            System.out.printf("Preprocessed String: %s\n", map.preprocessing(input));

            System.out.println("\n\nThe original (unsorted) map:");
            map.printMap();

            mergeSort.sort(map);

            System.out.println("\n\nThe sorted map:");
            mergeSort.printSortedMap();
        }
        else{
            System.out.println("Please enter proper input for input1.");
        }

        check = map2.checkInput(map2.preprocessing(input2));

        if(check){
            System.out.printf("\n\nOriginal String: %s\n", input2);
            System.out.printf("Preprocessed String: %s\n", map2.preprocessing(input2));

            System.out.println("\n\nThe original (unsorted) map:");
            map2.printMap();

            mergeSort.sort(map2);

            System.out.println("\n\nThe sorted map:");
            mergeSort.printSortedMap();
        }
        else{
            System.out.println("Please enter proper input for input2.");
        }


    }

}